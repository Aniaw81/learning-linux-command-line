#!/usr/bin/env bash
# A comment
echo -e "\n\tHello from the Test Script!\n"
